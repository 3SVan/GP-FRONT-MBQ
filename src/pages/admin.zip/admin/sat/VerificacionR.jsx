import React, { useState } from "react";
import { Search } from "lucide-react";
import { SatAPI } from "../../../api/sat.api";
import SystemAlert from "../../../components/ui/SystemAlert";
import InlineLoading from "../../../components/ui/InlineLoading";

function VerificacionR() {
  const [rfc, setRfc] = useState("");
  const [loading, setLoading] = useState(false);

  const [alertOpen, setAlertOpen] = useState(false);
  const [alertConfig, setAlertConfig] = useState({
    type: "",
    title: "",
    message: "",
    showConfirm: false,
    onConfirm: null,
  });

  const validarLongitudRFC = (value) =>
    value.length >= 12 && value.length <= 13;

  const showAlert = (
    type,
    title,
    message,
    showConfirm = false,
    onConfirm = null,
  ) => {
    setAlertConfig({ type, title, message, showConfirm, onConfirm });
    setAlertOpen(true);
  };

  // ✅ AHORA consulta el backend (BD)
  const buscarRFC = async () => {
    const raw = rfc.replace(/\s+/g, "").trim().toUpperCase();

    // ✅ 1) Validaciones ANTES de pegar al backend
    if (!raw) {
      showAlert(
        "error",
        "RFC Requerido",
        "Por favor ingrese un RFC para realizar la búsqueda.",
      );
      return;
    }

    if (!validarLongitudRFC(raw)) {
      showAlert(
        "error",
        "Longitud Inválida",
        "El RFC debe tener entre 12 y 13 caracteres.",
      );
      return;
    }

    // ✅ 2) Un solo request
    try {
      setLoading(true);

      const { data } = await SatAPI.quickCheckRfc(raw);
      // data: { found:boolean, rfc, situation?, name?, data? }

      if (data?.found) {
        showAlert(
          "error",
          "RFC No Aceptado",
          `Identificado en la lista SAT.\n` +
            `${data?.situation ? `Situación: ${data.situation}\n` : ""}` +
            `${data?.name ? `Nombre: ${data.name}` : ""}`.trim(),
        );
      } else {
        showAlert(
          "success",
          "RFC Aceptado",
          "No se encuentra en el listado cargado del SAT (según la última actualización).",
        );
      }
    } catch (err) {
      const msg = err?.response?.data?.message || "Error consultando SAT";
      showAlert("error", "Error", msg);
    } finally {
      setLoading(false);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === "Enter") buscarRFC();
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 bg-beige min-h-screen">
      <div className="max-w-2xl lg:max-w-4xl mx-auto">
        <div className="mb-6 sm:mb-8 text-center">
          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-darkBlue mb-3 sm:mb-4">
            Verificación de RFC
          </h1>
          <p className="text-midBlue text-base sm:text-lg lg:text-xl">
            Consulta de proveedores en lista negra del SAT
          </p>
        </div>

        <div className="bg-white rounded-lg sm:rounded-xl border-2 border-lightBlue p-4 sm:p-6 lg:p-8 shadow-lg">
          <div className="mb-4 sm:mb-6">
            <h2 className="text-lg sm:text-xl lg:text-2xl font-semibold text-darkBlue mb-2">
              Consulta de RFC
            </h2>
            <p className="text-midBlue text-sm sm:text-base">
              Ingresa el RFC del proveedor para verificar si se encuentra en la
              lista negra del SAT
            </p>
          </div>

          <div className="space-y-4 sm:space-y-6">
            <div>
              <label
                htmlFor="rfc"
                className="block text-sm sm:text-base font-medium text-darkBlue mb-2"
              >
                RFC del Proveedor *
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-4 w-4 sm:h-5 sm:w-5 text-midBlue" />
                </div>
                <input
                  type="text"
                  id="rfc"
                  value={rfc}
                  onChange={(e) => setRfc(e.target.value.toUpperCase())}
                  onKeyPress={handleKeyPress}
                  placeholder="Ingresa el RFC (12-13 caracteres)"
                  className="block w-full pl-9 sm:pl-10 pr-4 py-2 sm:py-3 border-2 border-lightBlue rounded-lg focus:ring-2 focus:ring-midBlue focus:border-midBlue text-darkBlue placeholder-midBlue text-sm sm:text-base"
                  maxLength={13}
                  disabled={loading}
                />
              </div>
            </div>

            <button
              onClick={buscarRFC}
              disabled={!rfc.trim() || loading}
              className="w-full bg-midBlue text-white py-2 sm:py-3 px-4 sm:px-6 rounded-lg hover:bg-darkBlue transition duration-200 font-medium disabled:bg-lightBlue disabled:cursor-not-allowed flex items-center justify-center gap-2 text-sm sm:text-base"
            >
              <Search className="w-4 h-4 sm:w-5 sm:h-5" />
              {loading ? "Verificando..." : "Verificar RFC"}
            </button>
            {loading && (
              <div className="mt-4">
                <InlineLoading text="Verificando RFC..." />
              </div>
            )}
          </div>
        </div>
      </div>

      <SystemAlert
        open={alertOpen}
        type={alertConfig.type}
        title={alertConfig.title}
        message={alertConfig.message}
        onClose={() => setAlertOpen(false)}
        showConfirm={alertConfig.showConfirm}
        onConfirm={alertConfig.onConfirm}
        confirmText="Confirmar"
        cancelText="Cancelar"
        acceptText="Aceptar"
      />
    </div>
  );
}

export default VerificacionR;
