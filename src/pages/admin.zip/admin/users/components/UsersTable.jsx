// src/pages/admin/users/components/UsersTable.jsx
import React from "react";
import { Eye, Edit, Trash2, Search } from "lucide-react";
import LoadingState from "../../../../components/ui/LoadingState";
import StatusBadge, {
  roleToneFromText,
  statusToneFromText,
} from "../../../../components/ui/StatusBadge";

export default function UsersTable({
  loading = false,
  usuariosFiltrados = [],
  onView,
  onEdit,
  onDelete,
}) {
  return (
    <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
      {loading ? (
        <div className="p-6">
          <LoadingState
            compact
            title="Cargando usuarios..."
            subtitle="Estamos obteniendo la información del módulo de usuarios."
          />
        </div>
      ) : (
        <>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50">
                  <th className="px-6 py-4 text-left text-xs font-semibold uppercase tracking-wider text-slate-600">
                    Usuario
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-semibold uppercase tracking-wider text-slate-600">
                    Departamento
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-semibold uppercase tracking-wider text-slate-600">
                    Rol
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-semibold uppercase tracking-wider text-slate-600">
                    Estatus
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-semibold uppercase tracking-wider text-slate-600">
                    Acciones
                  </th>
                </tr>
              </thead>

              <tbody className="divide-y divide-slate-100">
                {usuariosFiltrados.map((usuario) => (
                  <tr
                    key={String(usuario.id)}
                    className="transition-colors hover:bg-slate-50"
                  >
                    <td className="px-6 py-4">
                      <div>
                        <div className="text-sm font-semibold text-slate-800">
                          {usuario.nombre}
                        </div>
                        <div className="text-sm text-slate-500">{usuario.email}</div>
                      </div>
                    </td>

                    <td className="px-6 py-4 text-sm text-slate-700">
                      {usuario.departamento}
                    </td>

                    <td className="px-6 py-4">
                      <StatusBadge tone={roleToneFromText(usuario.rol)}>
                        {usuario.rol}
                      </StatusBadge>
                    </td>

                    <td className="px-6 py-4">
                      <StatusBadge tone={statusToneFromText(usuario.estatus)}>
                        {usuario.estatus}
                      </StatusBadge>
                    </td>

                    <td className="px-6 py-4">
                      <div className="flex gap-2">
                        <button
                          onClick={() => onView?.(usuario.id)}
                          className="rounded-lg p-2 text-slate-500 transition hover:bg-slate-100 hover:text-slate-700"
                          title="Ver detalles"
                        >
                          <Eye className="h-4 w-4" />
                        </button>

                        <button
                          onClick={() => onEdit?.(usuario.id)}
                          className="rounded-lg p-2 text-green-600 transition hover:bg-green-50 hover:text-green-700"
                          title="Editar"
                        >
                          <Edit className="h-4 w-4" />
                        </button>

                        <button
                          onClick={() => onDelete?.(usuario.id)}
                          className="rounded-lg p-2 text-red-600 transition hover:bg-red-50 hover:text-red-700"
                          title="Eliminar"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {usuariosFiltrados.length === 0 && (
            <div className="py-12 text-center">
              <div className="mb-3 text-slate-400">
                <Search className="mx-auto h-12 w-12" />
              </div>
              <p className="text-lg font-medium text-slate-700">
                No se encontraron usuarios
              </p>
              <p className="text-slate-500">
                Intenta ajustar los filtros de búsqueda
              </p>
            </div>
          )}
        </>
      )}
    </div>
  );
}